create definer = root@localhost view myview as
select `demo`.`a`.`a` AS `a`, `demo`.`a`.`id` AS `id`, `demo`.`a`.`score` AS `score`, `demo`.`a`.`style` AS `style`
from `demo`.`a`
where (`demo`.`a`.`score` < 80);

